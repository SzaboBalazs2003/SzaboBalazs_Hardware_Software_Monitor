﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HardWare_SoftWare_Monitor
{
    class Software
    {
        public string Nev { get; set; }
        public string Version { get; set; }
        public string Ujabb { get; set; }

        public Software(string sor)
        {
            string[] resz = sor.Split(',');
            Nev = resz[0];
            Version = resz[1];
            Ujabb = "Nincs információ";
        }
    }
}
