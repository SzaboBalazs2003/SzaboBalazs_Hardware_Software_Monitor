﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HardWare_SoftWare_Monitor
{
    class Drivers
    {
        public string Eszk { get; set; }
        public string Gyart { get; set; }
        public string Vers { get; set; }
        public Drivers(string info)
        {
            string[] resz = info.Split(',');
            Eszk = resz[0];
            Gyart = resz[1];
            Vers = resz[2];
        }
    }
}
