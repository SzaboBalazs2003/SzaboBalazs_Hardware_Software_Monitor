﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Collections;
using System.Collections.Specialized;
using System.Windows.Threading;
using System.IO;
using System.Management;


namespace HardWare_SoftWare_Monitor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer idozito = new DispatcherTimer();
        public MainWindow()
        {
            InitializeComponent();
            idozito.Interval = TimeSpan.FromSeconds(1);
            idozito.Tick += Monitor;
            Beolvasas();
            Drivers();
        }
        List<Software> softwarelist = new List<Software>();
        public void Beolvasas()
        {
            string uninstall = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall";
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(uninstall))
            {
                foreach (string item in key.GetSubKeyNames())
                {
                    using (RegistryKey subkey = key.OpenSubKey(item))
                    {
                        var nev = subkey.GetValue("DisplayName");
                        var vers = subkey.GetValue("DisplayVersion");
                        if (nev != null)
                        {
                            if (vers != null)
                            {
                                string nev1 = nev.ToString();
                                string vers1 = vers.ToString();
                                string sor = nev1 + "," + vers1;
                                softwarelist.Add(new Software(sor));
                            }
                        }
                    }
                }
            }
            foreach (var item in softwarelist)
            {
                szoftverdata.Items.Add(item);
            }
        }
        List<Drivers> driverek = new List<Drivers>();
        public void Drivers()
        {
            ManagementObjectSearcher objSearcher = new ManagementObjectSearcher("Select * from Win32_PnPSignedDriver");

            ManagementObjectCollection objCollection = objSearcher.Get();

            foreach (ManagementObject obj in objCollection)
            {
                string info = Convert.ToString(obj["DeviceName"]) + "," + Convert.ToString(obj["Manufacturer"]) + "," + Convert.ToString(obj["DriverVersion"]);
                driverek.Add(new Drivers(info));
            }
            driverlista.DataContext = driverek;
            foreach (var item in driverek)
            {
                driverlista.Items.Add(item);
            }
        }

        private void stop_Click(object sender, RoutedEventArgs e)
        {
            idozito.Stop();
        }

        private void start_Click(object sender, RoutedEventArgs e)
        {
            idozito.Start();
        }

        PerformanceCounter memorias = new PerformanceCounter("Memory", "% Committed Bytes In Use");
        PerformanceCounter memoriaa = new PerformanceCounter("Memory", "Available MBytes");
        PerformanceCounter cpu = new PerformanceCounter("Processor", "% Processor Time", "_Total");

        public void Monitor(object sender, EventArgs e)
        {
            memo.Content = "Felhasznált memória: " + Math.Round(memorias.NextValue()).ToString() + "%";
            elmemo.Content = "Elérhető memória: " + memoriaa.NextValue().ToString() + "Mb";
            cputime.Value = cpu.NextValue();
            idozito.Stop();
            idozito.Start();
        }

        private void exp_Click(object sender, RoutedEventArgs e)
        {
            szoftverdata.SelectAllCells();
            szoftverdata.ClipboardCopyMode = DataGridClipboardCopyMode.IncludeHeader;
            ApplicationCommands.Copy.Execute(null, szoftverdata);
            szoftverdata.UnselectAllCells();
            String result = (string)Clipboard.GetData(DataFormats.CommaSeparatedValue);
            SaveFileDialog mentes = new SaveFileDialog();
            mentes.Filter = "CSV állományok (*.csv)|*.csv";
            mentes.ShowDialog();
            StreamWriter sw = new StreamWriter(mentes.FileName, false, Encoding.UTF8);
            foreach (var item in result)
            {
                sw.Write(item);
            }
            sw.Close();
        }

        private void imp_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog betolt = new OpenFileDialog();
            betolt.Filter = "CSV állományok (.csv)|*.csv";
            betolt.ShowDialog();
            softwarelist.Clear();
            szoftverdata.Items.Clear();
            StreamReader sr = new StreamReader(betolt.FileName);
            while (!sr.EndOfStream)
            {
                string sor1 = sr.ReadLine();
                softwarelist.Add(new Software(sor1));
            }
            sr.Close();
            szoftverdata.DataContext = softwarelist;
            foreach (var item in softwarelist.Skip(1))
            {
                szoftverdata.Items.Add(item);
            }
        }
        private void hardverbe_Click(object sender, RoutedEventArgs e)
        {
            ManagementObjectSearcher videocontrol = new ManagementObjectSearcher("SELECT * FROM Win32_VideoController");
            foreach (ManagementObject item in videocontrol.Get())
            {
                
                videocard.Content = "Videókártya: " + item["Name"] + ", Driver verziója: " + item["DriverVersion"];
            }
            ManagementObjectSearcher cpu = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");
            foreach (ManagementObject item in cpu.Get())
            {
                processzor.Content = "Processzor: " + item["Name"];
            }
            ManagementObjectSearcher alaplap = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BaseBoard");
            foreach (ManagementObject item in alaplap.Get())
            {
                motherboard.Content = "Alaplap gyártója, típusa: " + item["Manufacturer"] + ", " + item["Name"];
            }
            ManagementObjectSearcher memory = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");
            foreach (ManagementObject item in memory.Get())
            {
                memoria.Content = "Memória: " + item["Name"];
            }
            ManagementObjectSearcher monitor = new ManagementObjectSearcher("SELECT * FROM Win32_DesktopMonitor");
            foreach (ManagementObject item in monitor.Get())
            {
                Monitoreszk.Content = "Monitor: " + item["Name"];
            }
        }
    }
}
